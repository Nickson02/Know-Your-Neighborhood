package com.lau.kyn.google.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.lau.kyn.google.dao.Store;



@Service
@Transactional
public interface StoreService {
	public void postStore(Store store);
	public List<Store> getStore();
	public Optional<Store> getStoreID(int store_id);
	public void deleteStoreID(int store_id);
	public List<Store> searchByKey(String keyword);
}
