package com.lau.kyn.google.dao;

//Create enumeration for Local, Google and Facebook
public enum AuthProvider {
	local,
	google,
	facebook
}
