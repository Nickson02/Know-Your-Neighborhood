package com.lau.kyn.google.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lau.kyn.google.dao.Store;
import com.lau.kyn.google.service.StoreService;





@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping(value = "/kyn")
public class StoreController {

	@Autowired
	private StoreService storeService;
	
	//Post store
	@PostMapping(value = "/store")
	public void postStore(@RequestBody Store store) {
		storeService.postStore(store);
		System.out.println("The stores have been successfully posted");
	}
	
	//Get all the store information
	@GetMapping(value = "/store")
	public List<Store> getStore(){
		System.out.println("Information of all stores are displayed");
		return storeService.getStore();
	}
	
	//Search by store id 
	@GetMapping(value = "/store/{store_id}")
	public Optional<Store> getStoreId(@PathVariable int store_id){
		return storeService.getStoreID(store_id);
	}
	
	//Delete by store id
	@DeleteMapping(value = "/store/{store_id}")
	public void deleteStoreId(@PathVariable int store_id) {
		storeService.deleteStoreID(store_id);
		System.out.println("The store ID: " + store_id + "has been deleted successfully");
	}
	
	//Update by store id
	@PutMapping(value = "/store/{store_id}")
	public Store updateStore(@RequestBody Store store, @PathVariable int store_id) {
		
		//Get storeId which the user wants to update
		Optional<Store> oldStore = storeService.getStoreID(store_id);
		System.out.println("The store id that will be update: " + oldStore);
		
		//Save the oldStore into updateStore
		Store updateStore = oldStore.get();
		System.out.println("The store information that will be updated: " + oldStore.toString());
		
		//Updating the store information with the new one .....
		updateStore.setName(store.getName());
		updateStore.setPhone_number(store.getPhone_number());
		updateStore.setLocalities(store.getLocalities());
		
		
		storeService.postStore(updateStore);
		
		System.out.println("Updated store information: " + updateStore.toString());
		return updateStore;
	}
	
	//Search Store by Store Name, Store Phone_number, Store Localities 
	@GetMapping(value = "/storeKey/{keyword}")
	public List<Store> searchByKey(@PathVariable String keyword) {
		return storeService.searchByKey(keyword);
	}
	
	
}
