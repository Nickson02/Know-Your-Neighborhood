package com.lau.kyn.google.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lau.kyn.google.dao.Store;
import com.lau.kyn.google.repository.StoreRepository;



@Service
@Transactional
public class StoreServiceImpl implements StoreService {

	@Autowired
	private StoreRepository storeRepository;
	
	@Override
	public void postStore(Store store) {
		storeRepository.save(store);
		
	}

	@Override
	public List<Store> getStore() {
		return storeRepository.findAll();
	}

	@Override
	public Optional<Store> getStoreID(int store_id) {
		return storeRepository.findById(store_id);
	}

	@Override
	public void deleteStoreID(int store_id) {
		storeRepository.deleteById(store_id);
		
	}

	@Override
	public List<Store> searchByKey(String keyword) {
		return storeRepository.searchByKey(keyword);
	}

}
