import React, { Component } from 'react';


class  ContactUsComponent extends Component {
    render() {
        return (
            <div className="" >
                <h2>Contact Us</h2>
                <br/><br/><br/>
                <div  className="row">
                    <div className="col-md-6">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d254992.96973880348!2d101.63208420051473!3d3.023304344889059!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc461ea0655555%3A0xdf650dd8a08dee81!2sLithan%20College!5e0!3m2!1sen!2smy!4v1647386823445!5m2!1sen!2smy" frameborder="0" allowfullscreen></iframe>                    
                    </div>
                    <div className="col-md-6">
                        <div>                           
                            <div>
                                <h4>Location:</h4>
                                <p>5JWM+58 Kuala Lumpur, Federal Territory of Kuala Lumpur</p>
                            </div>
                        </div>
                        <div >                           
                            <div>
                                <h4>Email:</h4>
                                <p>kyn@example.com</p>
                            </div>
                        </div>
                        <div >                           
                            <div>
                                <h4>Call:</h4>
                                <p>0362790571</p>
                            </div>
                        </div>
                    </div>
                    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
                </div>
                
            </div>
        )
    }
}

export default ContactUsComponent;