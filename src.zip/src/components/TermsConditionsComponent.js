import React, { Component } from 'react';


class TermsConditionsComponent extends Component {
    render() {
        return (
            <div className="" >
                <h2>Terms of Use</h2>
                <br/><br/><br/>
                <div>
                    <h3>1. AGREEMENT TO TERMS</h3>
                    <p>These Terms of Use constitute a legally binding agreement made between you, whether personally or on behalf of an entity (“you”) and KYN Pte Ltd Company " 
                        “<strong>we</strong>," “<strong>us</strong>," or “<strong>our</strong>”), concerning your access to and use of the 8b-c74c-db68-d12810736807" 
                        kyn website as well as any other media form, media channel, mobile website or mobile application related, linked, 
                        or otherwise connected thereto (collectively, the “Site”).</p>
                    <h3>2. INTELLECTUAL PROPERTY RIGHTS</h3>
                    <p>Unless otherwise indicated, the Site is our proprietary
                        property and all source code, databases, functionality, software, website
                        designs, audio, video, text, photographs, and graphics on the Site
                        (collectively, the “Content”) and the trademarks, service marks, and logos
                        contained therein (the “Marks”) are owned or controlled by us or licensed to
                        us, and are protected by copyright and trademark laws and various other
                        intellectual property rights and unfair competition laws of the United States, international copyright laws, 
                        and international conventions. The Content and the Marks are provided on the
                        Site “AS IS” for your information and personal use only. Except as expressly provided in these Terms
                        of Use, no part of the Site and no Content or Marks may be copied, reproduced,
                        aggregated, republished, uploaded, posted, publicly displayed, encoded,
                        translated, transmitted, distributed, sold, licensed, or otherwise exploited
                        for any commercial purpose whatsoever, without our express prior written
                        permission.</p>
                        <h3>3. USER REPRESENTATIONS</h3>
                        <p>By using the Site, you represent and warrant that:  all registration information you submit will be true, accurate, current, and complete; 
        If you provide any information that is untrue, inaccurate, not current, or incomplete, we have the right to suspend or terminate your account 
        and refuse any and all current or future use of the Site (or any portion thereof).
        USER REGISTRATION You may be required to register with the Site. You agree to keep your password confidential and will be responsible 
        for all use of your account and password. We reserve the right to remove, reclaim, or change a username you select if we determine, in our sole discretion, 
        that such username is inappropriate, obscene, or otherwise objectionable:As part of the functionality of the Site, you may link your account with 
        online accounts you have with third-party service providers (each such account, a “Third-Party Account”) by either: (1) providing your Third-Party
         Account login information through the Site; or (2) allowing us to access your Third-Party Account, as is permitted under the applicable terms and conditions 
         that govern your use of each Third-Party Account. You represent and warrant that you are entitled to disclose your Third-Party Account login information to us 
         and/or grant us access to your Third-Party Account, without breach by you of any of the terms and conditions that govern your use of the applicable Third-Party 
         Account, and without obligating us to pay any fees or making us subject to any usage limitations imposed by the third-party service provider of the Third-Party 
         Account. By granting us access to any Third-Party Accounts, you understand that (1) we may access, make available, and store (if applicable) any content that you 
         have provided to and stored in your Third-Party Account (the “Social Network Content”) so that it is available on and through the Site via your account, including 
         without limitation any friend lists and (2) we may submit to and receive from your Third-Party Account additional information to the extent you are notified when 
         you link your account with the Third-Party Account. Depending on the Third-Party Accounts you choose and subject to the privacy settings that you have set in such 
         Third-Party Accounts, personally identifiable information that you post to your Third-Party Accounts may be available on and through your account on the Site. 
         Please note that if a Third-Party Account or associated service becomes unavailable or our access to such Third Party Account is terminated by the third-party 
         service provider, then Social Network Content may no longer be available on and through the Site. You will have the ability to disable the connection between your 
         account on the Site and your Third-Party Accounts at any time. PLEASE NOTE THAT YOUR RELATIONSHIP WITH THE THIRD-PARTY SERVICE PROVIDERS ASSOCIATED WITH YOUR 
         THIRD-PARTY ACCOUNTS IS GOVERNED SOLELY BY YOUR AGREEMENT(S) WITH SUCH THIRD-PARTY SERVICE PROVIDERS. We make no effort to review any Social Network Content for 
         any purpose, including but not limited to, for accuracy, legality, or non-infringement, and we are not responsible for any Social Network Content. You acknowledge 
         and agree that we may access your email address book associated with a Third-Party Account and your contacts list stored on your mobile device or tablet computer 
         solely for purposes of identifying and informing you of those contacts who have also registered to use the Site. You can deactivate the connection between the Site 
         and your Third-Party Account by contacting us using the contact information below or through your account settings (if applicable). We will attempt to delete any 
         information stored on our servers that was obtained through such Third-Party Account, except the username and profile picture that become associated with your
          account.You acknowledge and agree that any questions, comments, suggestions, ideas, feedback, or other information regarding the Site ("Submissions") provided 
          by you to us are non-confidential and shall become our sole property. We shall own exclusive rights, including all intellectual property rights, and shall be 
          entitled to the unrestricted use and dissemination of these Submissions for any lawful purpose, commercial or otherwise, without acknowledgment or compensation 
          to you. You hereby waive all moral rights to any such Submissions, and you hereby warrant that any such Submissions are original with you or that you have the 
          right to submit such Submissions. You agree there shall be no recourse against us for any alleged or actual infringement or misappropriation of any proprietary 
          right in your Submissions.We reserve theright, but not the obligation, to: (1) monitor the Site for violations ofthese Terms of Use; (2) take appropriate legal 
          action against anyone who, inour sole discretion, violates the law or these Terms of Use, including withoutlimitation, reporting such user to law enforcement 
          authorities; (3) in our solediscretion and without limitation, refuse, restrict access to, limit theavailability of, or disable (to the extent technologically 
          feasible) any ofyour Contributions or any portion thereof; (4) in our sole discretion andwithout limitation, notice, or liability, to remove from the Site or 
          otherwisedisable all files and content that are excessive in size or are in any wayburdensome to our systems; and (5) otherwise manage the Site in a mannerdesigned 
          to protect our rights and property and to facilitate the properfunctioning of the Site.</p>
                </div>
                
            </div>
        )
    }
}

export default TermsConditionsComponent;