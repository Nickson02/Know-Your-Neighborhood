import React, { Component } from 'react'
import StoreService from '../service/StoreService'

class ViewStoreComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            store_id: this.props.match.params.store_id,
            store: {}
        }
    }

    componentDidMount(){
        StoreService.getStoreById(this.state.store_id).then( res => {
            this.setState({store: res.data});
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Store Details</h3>
                    <div className = "card-body col-md-8 offset-md-4">
                                <table >
                                    <tbody>
                                        <tr>
                                            <td>Store Name:</td>
                                            <td >{ this.state.store.name}</td>
                                        </tr>
                                        <tr>
                                            <td> Phone number:</td>
                                            <td>{ this.state.store.phone_number}</td>
                                        </tr>
                                        <tr>
                                            <td>Localities :</td>
                                            <td>{ this.state.store.localities}</td>
                                        </tr>
                                    </tbody>
                                </table>
                    </div>

                </div>
                <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
            </div>
        )
    }
}

export default ViewStoreComponent