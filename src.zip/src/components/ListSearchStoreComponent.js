import React, { Component } from 'react'
import StoreService from '../service/StoreService'

class ListSearchStoreComponent extends Component {
    
    constructor(props) {
        super(props)

        this.state = {
                store: [],
                keyword:this.props.match.params.keyword
        }
       
        this.searchStore = this.searchStore.bind(this);
    }

   
    viewStore(sid){
        this.props.history.push(`/view-store/${sid}`);
    }
   

    componentDidMount(){
        StoreService.searchStore(this.state.keyword).then((res) => {
            this.setState({ store: res.data});
        });

    }

    
    changeSearchHandler= (event) => {
        console.log("search Handler");
        this.setState({keyword: event.target.value});
    }

    searchStore(keyword){
        console.log("search Store Method "+keyword);
         this.props.history.push(`/search-store/${keyword}`);
        

    }



    render() {
        return (
            <div>
                 <h2 className="text-center">Search Store Results</h2>
                 
                 <nav className="navbar navbar-light bg-light">
                  <form className="form-inline">
                    <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" value={this.state.keyword} onChange={this.changeSearchHandler}/>
                   
                    <button onClick={ () => this.searchStore(this.state.keyword)} className="btn btn-info">Search </button>

                  </form>
                </nav>

                <div className = "row">
                        <table className = "table table-hover table-bordered text-center">

                            <thead thead-light>
                                <tr>
                                    <th  scope="col"> No. </th>
                                    <th  scope="col"> Store Name</th>
                                    <th  scope="col" > Phone Number </th>
                                    <th  scope="col" > Localities</th>
                                    <th  scope="col" > Actions</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.store.map(
                                        store => 
                                        <tr key = {store.id}>
                                                <th > {store.id} </th>   
                                                <td > {store.name} </td>   
                                                <td > {store.phone_number}</td>
                                                <td > {store.localities}</td>
                                                
                                             <td>                                                
                                                 <button  onClick={ () => this.viewStore(store.id)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                </div>
                <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
            </div>
        )
    }
}

export default ListSearchStoreComponent