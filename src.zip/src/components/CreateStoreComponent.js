import React, { Component } from 'react'
import StoreService from '../service/StoreService';

class CreateStoreComponent extends Component {

    constructor(props) {
        super(props)

        this.state = {
            // step 2
            store_id: this.props.match.params.store_id,
            name: '',
            phone_number: '',
            localities: ''
            
        }
        this.changeNameHandler = this.changeNameHandler.bind(this);
        this.changePhoneHandler = this.changePhoneHandler.bind(this);
        this.changeLocalitiesHandler = this.changeLocalitiesHandler.bind(this);
        this.saveOrUpdateStore = this.saveOrUpdateStore.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.store_id === '_add'){
            return
        }else{
            StoreService.getStoreById(this.state.store_id).then( (res) =>{
                let store = res.data;
                this.setState({
                    name: store.name,
                    phone_number: store.phone_number,
                    localities : store.localities,                   
                });
            });
        }        
    }


    saveOrUpdateStore = (e) => {
        e.preventDefault();
        let store = {name: this.state.name, phone_number: this.state.phone_number, localities: this.state.localities};
        console.log('store => ' + JSON.stringify(store));

        // step 5
        if(this.state.store_id === '_add'){
            StoreService.createStore(store).then(res =>{
                this.props.history.push('/store');
            });
        }else{
            StoreService.updateStore(store, this.state.store_id).then( res => {
                this.props.history.push('/store');
            });
        }
    }
    
    changeNameHandler= (event) => {
        this.setState({name: event.target.value});
    }

    changePhoneHandler= (event) => {
        this.setState({phone_number: event.target.value});
    }

    changeLocalitiesHandler= (event) => {
        this.setState({localities: event.target.value});
    }

    cancel(){
        this.props.history.push('/store');
    }

    getTitle(){
        if(this.state.store_id === '_add'){
            return <h3 className="text-center">Add Store</h3>
        }else{
            return <h3 className="text-center">Update Store</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Store Name : </label>
                                            <input placeholder="Store Name" name="name" className="form-control" 
                                                value={this.state.name} onChange={this.changeNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Phone Number: </label>
                                            <input placeholder="Phone Number" name="phone_number" className="form-control" 
                                                value={this.state.phone_number} onChange={this.changePhoneHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Localities </label>
                                            <input placeholder="Localities" name="localities" className="form-control" 
                                                value={this.state.localities} onChange={this.changeLocalitiesHandler}/>
                                        </div>                                       


                                        <button className="btn btn-success" onClick={this.saveOrUpdateStore}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
                   <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
            </div>
        )
    }
}

export default CreateStoreComponent