import React, { Component } from 'react';
import mission from '../img/mission.png';

class AboutUsComponent extends Component {
    render() {
        return (
            <div className="" >
                <h2>About Us</h2>
                <br/><br/><br/>
                <div  className="row">
                    <div className="col-md-6">
                        <h3>Our Mission</h3>
                        <p>To let the users know what kind of stores in their neighborhood by searching the area they are in</p>
                        <br></br>
                        <h3>What we do?</h3>
                        <p>We gather information about the stores that are available. Users can freely search using the stores that are registered with us</p>  
                        <br></br>
                        <h3>History</h3>
                        <p>The KYN appilcation i developed on 2022. It is founded by Mr.Lau.</p>
                        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>                                              
                    </div>
                    <div className="col-md-6">
                        <div>                           
                             <img src={mission} alt="Mission Image" ></img>
                        </div>
                    </div>
                </div>
                
            </div>
        )
    }
}

export default AboutUsComponent;