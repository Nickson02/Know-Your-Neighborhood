import React, { Component } from 'react'
import StoreService from '../service/StoreService'

class ListStoreComponent extends Component {
    
    constructor(props) {
        super(props)

        this.state = {
                stores: [],
                keyword:'',
        }
        this.addStore = this.addStore.bind(this);
        this.editStore = this.editStore.bind(this);
        this.deleteStore = this.deleteStore.bind(this);
        this.searchStore = this.searchStore.bind(this);
    }

    componentDidMount(){
        StoreService.getStore().then((res) => {
            this.setState({ stores: res.data});
        });

    }

    deleteStore(id){
        StoreService.deleteStore(id).then( res => {
            this.setState({stores: this.state.stores.filter(store => store.id !== id)});
        });
    }
    viewStore(id){
        this.props.history.push(`/view-store/${id}`);
    }
    editStore(id){
        this.props.history.push(`/add-store/${id}`);
    }

    addStore(){
        this.props.history.push('/add-store/_add');
    }


    changeSearchHandler= (event) => {
        console.log("search Handler");
        this.setState({keyword: event.target.value});
    }

    searchStore(keyword){
        console.log("search Store Method "+keyword);
         this.props.history.push(`/search-store/${keyword}`);
        

    }



    render() {
        return (
            <div>
                <h2 className="text-center">Store List</h2>
                <div className = "row">               
                    <div className="col-md-8">
                        <button className="btn btn-info" onClick={this.addStore}> Add Store</button>
                    </div>
                    <div className="col-md-4 ">
                            <form className="form-inline">
                                <input className="form-control " type="search" placeholder="Search" aria-label="Search" value={this.state.keyword} onChange={this.changeSearchHandler}/>                  
                                <button onClick={ () => this.searchStore(this.state.keyword)} className="btn btn-primary" >Search</button>
                            </form>
                    </div>
                </div>
                 




                <div className = "row">
                        <table className = "table table-hover table-bordered text-center">

                            <thead thead-light>
                                <tr>
                                    <th  scope="col"> No. </th>
                                    <th  scope="col"> Store Name</th>
                                    <th  scope="col" > Phone Number </th>
                                    <th  scope="col" > Localities</th>
                                    <th  scope="col" > Actions</th>                                   
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.stores.map(
                                        store => 
                                        <tr key = {store.id}>
                                                <th > {store.id} </th>   
                                                <td > {store.name} </td>   
                                                <td > {store.phone_number}</td>
                                                <td > {store.localities}</td>
                                                
                                             <td>
                                                 <button onClick={ () => this.editStore(store.id)} className="btn btn-info">Update </button>
                                                 <button  onClick={ () => this.deleteStore(store.id)} className="btn btn-info">Delete </button>
                                                 <button  onClick={ () => this.viewStore(store.id)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                </div>
                <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
            </div>
        )
    }
}

export default ListStoreComponent