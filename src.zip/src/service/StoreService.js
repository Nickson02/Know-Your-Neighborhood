import axios from 'axios';

const API_BASE_URL = "http://localhost:8080/kyn/store";

class StoreService {

    getStore(){
        console.log("Get All Store");
        return axios.get(API_BASE_URL);
    }


    getStoreById(store_id){
        console.log("Get Store by id " + store_id);
        return axios.get(API_BASE_URL + '/' + store_id);
    }


    createStore(store){
        console.log("Add New Store");
        return axios.post(API_BASE_URL, store);
    }


    updateStore(store, store_id){
        console.log("Update Store by id "+store_id);
        return axios.put(API_BASE_URL + '/' + store_id, store);
    }

    deleteStore(store_id){
        console.log("Delete Store " + store_id);
        return axios.delete(API_BASE_URL + '/' + store_id);
    }

    searchStore(keyword){
        console.log("Search keyword is  "+keyword);
        return axios.get("http://localhost:8080/kyn/storeKey" + '/' + keyword);
    }


}

export default new StoreService()