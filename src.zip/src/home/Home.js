import React, { Component } from 'react';
import './Home.css';
import kyn_img from '../img/kyn_home.png';

class Home extends Component {
    render() {
        return (
            <div className="home-container">
                    <h1 className="home-title">Know-Your-Neighborhood</h1>
                    <div className="container">
                        
                        <img src={kyn_img} alt="Welcome to KYN" ></img>
                    </div>
            </div>
        )
    }
}

export default Home;