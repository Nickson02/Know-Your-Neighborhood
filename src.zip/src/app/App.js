import React, { Component } from 'react';
import {Route, Switch} from 'react-router-dom';
import AppHeader from '../app/AppHeader';
import Home from '../home/Home';
import Login from '../user/login/Login';
import Signup from '../user/signup/Signup';
import Profile from '../user/profile/Profile';
import ListSearchStoreComponent from '../components/ListSearchStoreComponent';
import CreateStoreComponent from '../components/CreateStoreComponent';
import ViewStoreComponent from '../components/ViewStoreComponent';
import ListStoreComponent from '../components/ListStoreComponent';
import OAuth2RedirectHandler from '../user/oauth2/OAuth2RedirectHandler';
import NotFound from '../app/NotFound';
import LoadingIndicator from '../app/LoadingIndicator';
import { getCurrentUser } from '../service/OnlineService';
import PrivateRoute from '../app/PrivateRoute';
import Alert from 'react-s-alert';
import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';
import './App.css';
import AppFooter from './AppFooter';
import AboutUsComponent from '../components/AboutUsComponent';
import ContactUsComponent from '../components/ContactUsComponent';
import TermsConditionsComponent from '../components/TermsConditionsComponent';

export const ACCESS_TOKEN = 'accessToken';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      authenticated: false,
      currentUser: null,
      loading: false
    }

    this.loadCurrentlyLoggedInUser = this.loadCurrentlyLoggedInUser.bind(this);
    this.handleLogout = this.handleLogout.bind(this);
  }

  loadCurrentlyLoggedInUser() {
    this.setState({
      loading: true
    });

    getCurrentUser()
    .then(response => {
      this.setState({
        currentUser: response,
        authenticated: true,
        loading: false
      });
    }).catch(error => {
      this.setState({
        loading: false
      });  
    });    
  }

  handleLogout() {
    localStorage.removeItem(ACCESS_TOKEN);
    this.setState({
      authenticated: false,
      currentUser: null
    });
    Alert.success("You're safely logged out!");
  }

  componentDidMount() {
    this.loadCurrentlyLoggedInUser();
  }

  render() {
    if(this.state.loading) {
      return <LoadingIndicator />
    }

    return (
      <div className="app">
        <div className="app-top-box">
          <AppHeader authenticated={this.state.authenticated} onLogout={this.handleLogout} />
        </div>
        <div className="app-body app-body-container">
          <Switch>
            <Route exact path="/" component={Home}></Route>
            <Route exact path="/termsandcondition" component={TermsConditionsComponent}></Route> 
            <Route exact path="/contactus" component={ContactUsComponent}></Route> 
            <Route exact path="/aboutus" component={AboutUsComponent}></Route>            
            <PrivateRoute path="/profile" authenticated={this.state.authenticated} currentUser={this.state.currentUser}
              component={Profile}></PrivateRoute>
            <PrivateRoute path = "/store" authenticated={this.state.authenticated} currentUser={this.state.currentUser}
            component = {ListStoreComponent}></PrivateRoute>
            <PrivateRoute path = "/add-store/:store_id" authenticated={this.state.authenticated} currentUser={this.state.currentUser}
            component = {CreateStoreComponent}></PrivateRoute>
            <PrivateRoute path = "/view-store/:store_id" authenticated={this.state.authenticated} currentUser={this.state.currentUser}
            component = {ViewStoreComponent}></PrivateRoute>
            <PrivateRoute path = "/search-store/:keyword" authenticated={this.state.authenticated} currentUser={this.state.currentUser}
            component = {ListSearchStoreComponent}></PrivateRoute>
            <Route path="/login"
              render={(props) => <Login authenticated={this.state.authenticated} {...props} />}></Route>
            <Route path="/signup"
              render={(props) => <Signup authenticated={this.state.authenticated} {...props} />}></Route>
            <Route path="/oauth2/redirect" component={OAuth2RedirectHandler}></Route>  
            <Route component={NotFound}></Route>    
          </Switch>
        </div>
        <div className="app-bottom-box">
          <AppFooter/>
        </div>
        <Alert stack={{limit: 3}} 
          timeout = {3000}
          position='top-right' effect='slide' offset={65} />
      </div>
    );
  }
}

export default App;
