import React, { Component } from 'react'
import { Link, NavLink } from 'react-router-dom';
import './AppFooter.css';

class AppFooter extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <footer className="bg-dark text-center text-white footer navbar-fixed-bottom">
                    <div className="row">
                        <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                            KYN All Rights Reserved 2022
                        </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <NavLink to="/contactus">Contact Us</NavLink>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <NavLink to="/aboutus">About Us</NavLink>   
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <NavLink to="/termsandcondition"> Terms and Condition</NavLink>                         
                            </div>
                                         
                    </div>                    
                </footer>
            </div>
        )
    }
}

export default AppFooter